# Ethical & Data Transparency Compliance

This dataset is fully synthetic and contains no real human data.

No new human participants were recruited.
No IRB approval required.
All methods comply with relevant research and publication guidelines.

Data Availability:
The dataset repository provides full public access to the synthetic data and scripts.
